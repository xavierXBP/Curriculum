package com.example.prollecte10


import java.io.File

class ConnectionClass {
    companion object{
        var myfile: File? =null
    }
}