INSERT INTO Combustibles (nombre, precio) VALUES
('Gasolina 95', 1.50),
('Gasolina 98', 1.70),
('Gasoil', 1.40),
('Diesel', 1.50),
('Biodi�sel', 1.60),
('Biotanol', 1.80),
('Electricitat', 0.30);


INSERT INTO [dbo].[Depositos] ([id_combustible], [capacidad_total], [nivel_actual]) VALUES
(1, 10000.00, 9906.40),
(2, 8000.00, 5812.30),
(3, 12000.00, 8968.40),
(4, 12000.00, 8884.80),
(5, 7000.00, 4943.18),
(6, 5000.00, 2965.77),
(7, 2000.00, 1237.40);
GO

USE [Gasolinera]
GO

INSERT INTO [dbo].[Surtidores] ([estado]) VALUES
('Libre'),
('Ocupado'),
('Ocupado'),
('Libre'),
('Libre'),
('Libre'),
('Libre'),
('Libre');
GO
