﻿Imports System.Data.SqlClient

Public Class Form3
    Dim temporizador As New Timer() ' Timer para el llenado
    Dim timerCambioEstado As New Timer() ' Timer para cambiar el estado del surtidor después de 5s
    Dim tiempoTotal As Double ' Tiempo total del temporizador
    Dim incremento As Double ' Valor a sumar en cada tick
    Dim valorActual As Double ' Valor actual en Label4
    Dim connectionString As String = "Server=XAVI\SQLEXPRESS;Database=Gasolinera;Integrated Security=True;"

    ' Propiedades para almacenar los valores recibidos desde Form2
    Public preu As Double
    Public preu_L As Double
    Public sortidor As Integer

    Private Sub Form3_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.Size = New Size(350, 285)
        'Me.Location = New Point(500, 0)
        Text = "Comenzar"
        Label1.Font = New Font("Arial", 12, FontStyle.Bold)
        Label2.Font = New Font("Arial", 12, FontStyle.Bold)
        Label3.Font = New Font("Arial", 12, FontStyle.Bold)
        Label4.Font = New Font("Arial", 12, FontStyle.Bold)

        ' Configuración del GroupBox para mostrar el surtidor seleccionado
        GroupBox4.Text = "Sortidor " + sortidor.ToString()

        ' Habilitar los botones de control de llenado
        Button1.Enabled = True
        Button2.Enabled = False

        ' Asignar el precio por litro y el precio total insertado
        Label1.Text = preu_L.ToString() + "$/ Litro"
        Label2.Text = preu.ToString() + "$ Insertats"

        ' Evitar división por cero y calcular la cantidad de litros
        If preu_L <> 0 Then
            Dim resultado As Double = preu / preu_L
            Label3.Text = resultado.ToString("0.00") + " Litros"
        End If

        ' Configuración del Timer para el llenado
        AddHandler temporizador.Tick, AddressOf Temporizador_Tick
        temporizador.Interval = 100 ' Cada 100ms

        ' Configuración del Timer para cambiar estado a "Libre" después de 5s
        AddHandler timerCambioEstado.Tick, AddressOf TimerCambioEstado_Tick
        timerCambioEstado.Interval = 5000 ' 5 segundos

        Form2.Hide() ' Ocultar Form2 mientras está trabajando en Form3
        Form2.Label1.Text = "___"




    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        ' Cambiar colores de los botones para reflejar el estado
        Button2.BackColor = Color.Red
        Button1.BackColor = Color.Orange
        Button1.Enabled = False
        Button2.Enabled = True

        ' Calcular el tiempo total en segundos
        tiempoTotal = preu / preu_L / 2
        incremento = preu / (tiempoTotal * 10) ' Cada 100ms

        ' Inicializar valores
        valorActual = 0
        Label4.Text = valorActual.ToString("0.00")

        ' Iniciar Timer
        temporizador.Start()

        ' Marcar surtidor como "Ocupado" en la BD
        ActualizarEstadoSurtidor("Ocupado")
        Form2.Client = False

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        ' Cambiar colores de los botones para reflejar el estado
        Button1.BackColor = Color.Red
        Button2.BackColor = Color.Orange
        Button2.Enabled = False

        ' Parar el Timer de llenado
        temporizador.Stop()

        ' Iniciar Timer de 5 segundos para liberar el surtidor
        timerCambioEstado.Start()

        ' Realizar actualización de la base de datos: actualizar el nivel del depósito
        ActualizarDeposito()

        ' Insertar la transacción en la tabla Transacciones con el valor real de lo consumido (14 euros, por ejemplo)
        InsertarTransaccion(valorActual) ' Pasamos el valor real que se ha introducido
    End Sub

    Private Sub InsertarTransaccion(valorReal As Double)
        ' Obtener el id_deposito correspondiente al combustible seleccionado
        Dim idDeposito As Integer = ObtenerIdCombustibleSeleccionado()

        ' Calcular los litros consumidos en base al valor real ingresado
        Dim litrosConsumidos As Double = valorReal / preu_L ' El total de litros es el valor real dividido por el precio por litro

        ' Obtener la fecha actual
        Dim fechaTransaccion As DateTime = DateTime.Now

        ' Obtener el nivel actual del depósito antes de realizar la transacción
        Dim nivelActual As Double = ObtenerNivelActualDeposito(idDeposito)

        ' Insertar la transacción en la tabla Transacciones
        Dim query As String = "INSERT INTO Transacciones (id_deposito, id_combustible, precio, litros, fecha, nivel_actual) 
                           VALUES (@id_deposito, @id_combustible, @precio, @litros, @fecha, @nivel_deposito)"

        Using conn As New SqlConnection(connectionString)
            Using cmd As New SqlCommand(query, conn)
                cmd.Parameters.AddWithValue("@id_deposito", idDeposito) ' Usamos el id_deposito correspondiente al combustible
                cmd.Parameters.AddWithValue("@id_combustible", ObtenerIdCombustibleSeleccionado()) ' Obtenemos el id_combustible
                cmd.Parameters.AddWithValue("@precio", valorReal) ' El precio total de la transacción (valor real ingresado)
                cmd.Parameters.AddWithValue("@litros", litrosConsumidos) ' Los litros consumidos en base al valor real
                cmd.Parameters.AddWithValue("@fecha", fechaTransaccion) ' La fecha de la transacción
                cmd.Parameters.AddWithValue("@nivel_deposito", nivelActual) ' Agregar el nivel del depósito actual

                Try
                    conn.Open()
                    cmd.ExecuteNonQuery()
                    MessageBox.Show("Transacción registrada correctamente.")
                Catch ex As Exception
                    MessageBox.Show("Error al registrar la transacción: " & ex.Message)
                End Try
            End Using
        End Using
    End Sub


    Private Sub Temporizador_Tick(sender As Object, e As EventArgs)
        ' Aumentar el valor progresivamente
        valorActual += incremento
        Label4.Text = valorActual.ToString("0.00")

        ' Si alcanzamos el valor máximo (preu) o el usuario para el llenado, detener el Timer y ejecutar Button2_Click
        If valorActual >= preu Then
            temporizador.Stop() ' Detener el temporizador de llenado
            Label4.Text = preu.ToString("0.00") ' Asegurar precisión
            ' Llamar al evento de Button2_Click para detener el llenado y cambiar el estado
            Button2_Click(sender, e)
        End If
    End Sub

    Private Sub TimerCambioEstado_Tick(sender As Object, e As EventArgs)
        ' Detener el Timer después de 5s y cambiar el estado a "Libre"
        timerCambioEstado.Stop()
        ActualizarEstadoSurtidor("Libre")
    End Sub

    Private Sub ActualizarEstadoSurtidor(estado As String)
        Dim query As String = "UPDATE Surtidores SET estado = @estado WHERE id_deposito = @id"

        Using conn As New SqlConnection(connectionString)
            Using cmd As New SqlCommand(query, conn)
                cmd.Parameters.AddWithValue("@estado", estado)
                cmd.Parameters.AddWithValue("@id", sortidor)

                Try
                    conn.Open()
                    cmd.ExecuteNonQuery()
                    'MessageBox.Show("Surtidor " & sortidor & " actualizado a: " & estado)
                Catch ex As Exception
                    ' MessageBox.Show("Error al actualizar surtidor: " & ex.Message)
                End Try
            End Using
        End Using
    End Sub

    ' Método para actualizar el nivel del depósito en la base de datos
    Private Sub ActualizarDeposito()
        ' Obtener el id_combustible correspondiente al combustible seleccionado
        Dim idCombustible As Integer = ObtenerIdCombustibleSeleccionado()

        ' Obtener los litros consumidos
        Dim litrosConsumidos As Double = valorActual / preu_L ' El total de litros es el precio dividido por el precio por litro

        ' Obtener el nivel actual del depósito correspondiente al id_combustible antes de actualizarlo
        Dim nivelActual As Double = ObtenerNivelActualDeposito(idCombustible)

        ' Verificar que el nivel actual y los litros consumidos son correctos
        If nivelActual <= 0 Then
            Return ' Salir si el nivel es 0 o menor
        End If

        ' Verificar que los litros consumidos no sean más que los disponibles
        If litrosConsumidos > nivelActual Then
            Return ' Salir si no hay suficiente combustible
        End If

        ' Calcular el nuevo nivel del depósito después de restar los litros consumidos
        Dim nuevoNivel As Double = nivelActual - litrosConsumidos

        ' Actualizar el depósito con el nuevo nivel
        Dim query As String = "UPDATE Depositos SET nivel_actual = @nuevoNivel WHERE id_combustible = @id_combustible"

        Using conn As New SqlConnection(connectionString)
            Using cmd As New SqlCommand(query, conn)
                cmd.Parameters.AddWithValue("@nuevoNivel", nuevoNivel)
                cmd.Parameters.AddWithValue("@id_combustible", idCombustible) ' Usamos el id_combustible correspondiente al combustible

                Try
                    conn.Open()
                    Dim filasAfectadas As Integer = cmd.ExecuteNonQuery()
                    If filasAfectadas > 0 Then
                    Else
                    End If
                Catch ex As Exception
                End Try
            End Using
        End Using
    End Sub




    Private Function ObtenerNivelActualDeposito(idDeposito As Integer) As Double
        ' Esta función obtiene el nivel actual del depósito desde la base de datos
        Dim nivelActual As Double = 0
        Dim query As String = "SELECT nivel_actual FROM Depositos WHERE id_deposito = @id_deposito"

        Using conn As New SqlConnection(connectionString)
            Using cmd As New SqlCommand(query, conn)
                cmd.Parameters.AddWithValue("@id_deposito", idDeposito)

                Try
                    conn.Open()
                    nivelActual = Convert.ToDouble(cmd.ExecuteScalar()) ' Obtener el nivel actual del depósito
                Catch ex As Exception
                    MessageBox.Show("Error al obtener el nivel del depósito: " & ex.Message)
                End Try
            End Using
        End Using
        ' Label5.Text = nivelActual.ToString
        Return nivelActual
    End Function


    Private Function ObtenerIdCombustibleSeleccionado() As Integer
        ' Aquí, puedes obtener el id_del combustible desde Form2 o cualquier parte que maneje la selección
        ' Asumimos que carburanteSeleccionado contiene el nombre del combustible
        Dim idCombustible As Integer = 0
        Dim query As String = "SELECT id_combustible FROM Combustibles WHERE nombre = @nombre_combustible"
        Dim carburanteSeleccionado = Form2.carburanteSeleccionado
        Using conn As New SqlConnection(connectionString)
            Using cmd As New SqlCommand(query, conn)
                cmd.Parameters.AddWithValue("@nombre_combustible", carburanteSeleccionado)

                Try
                    conn.Open()
                    idCombustible = Convert.ToInt32(cmd.ExecuteScalar()) ' Obtiene el id_combustible
                Catch ex As Exception
                    MessageBox.Show("Error al obtener el id_combustible: " & ex.Message)
                End Try
            End Using
        End Using
        'Label5.Text = idCombustible.ToString
        Return idCombustible


    End Function

    Private Sub Label5_Click(sender As Object, e As EventArgs)

    End Sub
End Class
