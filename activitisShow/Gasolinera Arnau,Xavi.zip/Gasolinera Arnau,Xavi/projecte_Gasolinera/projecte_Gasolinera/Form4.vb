﻿Imports System.Data.SqlClient

Public Class Form4
    Public Client As Boolean

    Private Sub Form4_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Text = "Socis"
        Label1.Font = New Font("Arial", 12, FontStyle.Bold)
        TextBox1.Font = New Font("Arial", 12, FontStyle.Bold)
        TextBox2.Font = New Font("Arial", 12, FontStyle.Bold)
        Label2.Font = New Font("Arial", 12, FontStyle.Bold)

    End Sub
    Dim usuarioValido As Boolean = False

    ' Evento del botón para hacer la verificación del usuario y la contraseña
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        ' Obtener los valores del usuario y la contraseña desde los TextBox
        Dim usuario As String = TextBox1.Text
        Dim contrasena As String = TextBox2.Text

        ' Llamamos al método para verificar el usuario y la contraseña
        If VerificarUsuarioContrasena(usuario, contrasena) Then
            usuarioValido = True
        Else
            usuarioValido = False
            MessageBox.Show("Usuario o contraseña incorrectos.")
        End If
    End Sub

    ' Método para verificar el usuario y la contraseña en la base de datos
    Private Function VerificarUsuarioContrasena(usuario As String, contrasena As String) As Boolean
        Dim connectionString As String = "Server=XAVI\SQLEXPRESS;Database=Gasolinera;Integrated Security=True;"
        Dim query As String = "SELECT COUNT(*) FROM socis WHERE usuario = @usuario AND contrasena = @contrasena"
        Client = False


        ' Establecer la conexión con la base de datos
        Using conn As New SqlConnection(connectionString)
            Using cmd As New SqlCommand(query, conn)
                ' Añadir los parámetros para evitar inyecciones SQL
                cmd.Parameters.AddWithValue("@usuario", usuario)
                cmd.Parameters.AddWithValue("@contrasena", contrasena)

                Try
                    conn.Open()
                    ' Ejecutar la consulta y obtener el número de registros que coinciden
                    Dim count As Integer = Convert.ToInt32(cmd.ExecuteScalar())
                    MessageBox.Show("Ussuari trobat")

                    ' Establecer la variable client según el resultado
                    Client = (count > 0)

                    Return client
                Catch ex As Exception
                    MessageBox.Show("Error al consultar la base de datos: " & ex.Message)
                    Return False
                End Try
                Form2.Client = Client
            End Using
        End Using
    End Function


    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Form2.Client = Client
        'Form2.Label5.Text = Client
        Form2.Client = Client


        Me.Close()
    End Sub
End Class


