﻿Imports System.Data.SqlClient

Public Class Form2
    Dim connectionString As String = "Server=XAVI\SQLEXPRESS;Database=Gasolinera;Integrated Security=True;"
    Public preu
    Public preu_L
    Public numeroActual As String = ""
    Public sortidor
    Public Client As Boolean
    Public carburanteSeleccionado As String
    Dim carb As String

    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        carb = Form1.carburant

        Me.Size = New Size(700, 500)
        Me.Location = New Point(40, 40)
        Text = "Sortidors"
        carburanteSeleccionado = Form1.carburant
        ActualizarSurtidores()
        If (carb = "Electricitat") Then
            RadioButton1.Visible = False
            RadioButton2.Visible = False
            RadioButton3.Visible = False
            RadioButton4.Visible = False
            RadioButton5.Visible = False
            RadioButton6.Visible = False
            RadioButton10.Visible = True
            RadioButton11.Visible = True
        Else
            RadioButton1.Visible = True
            RadioButton2.Visible = True
            RadioButton3.Visible = True
            RadioButton4.Visible = True
            RadioButton5.Visible = True
            RadioButton6.Visible = True
            RadioButton10.Visible = False
            RadioButton11.Visible = False

        End If


    End Sub
    ' Evento común para manejar todos los botones de números del 0 al 9
    Private Sub NumeroBoton_Click(sender As Object, e As EventArgs) Handles Bt0.Click, bt1.Click, Bt2.Click, Bt3.Click, Bt4.Click, Bt5.Click, Bt6.Click, Bt7.Click, Bt8.Click, Bt9.Click
        ' Tomamos el texto del botón que fue presionado (el número del botón)
        Dim botonPulsado As Button = CType(sender, Button)
        Dim numero As String = botonPulsado.Text

        ' Concatenamos el número al número actual
        numeroActual &= numero

        ' Actualizamos el texto del Label1 con el número concatenado
        Label1.Text = numeroActual
    End Sub

    Private Sub ActualizarSurtidores()
        Dim query As String = "SELECT id_deposito, estado FROM Surtidores"

        Using conn As New SqlConnection(connectionString)
            Dim cmd As New SqlCommand(query, conn)
            Try
                conn.Open()
                
                Dim reader As SqlDataReader = cmd.ExecuteReader()

                ' Resetear todos los RadioButton antes de actualizar
                Dim radioButtons As RadioButton() = {RadioButton1, RadioButton2, RadioButton3, RadioButton4, RadioButton5, RadioButton6, RadioButton10, RadioButton11}
                For Each rb As RadioButton In radioButtons
                    rb.Enabled = True
                    rb.ForeColor = Color.Black
                    rb.BackColor = SystemColors.Control ' Restaurar color de fondo predeterminado
                Next

                While reader.Read()
                    Dim surtidorId As Integer = reader("id_deposito")
                    Dim estado As String = reader("estado").ToString().Trim()

                    Dim radioButton As RadioButton = Nothing

                    ' Asignamos el RadioButton correspondiente al surtidor
                    Select Case surtidorId
                        Case 1 : radioButton = RadioButton1
                        Case 2 : radioButton = RadioButton2
                        Case 3 : radioButton = RadioButton3
                        Case 4 : radioButton = RadioButton4
                        Case 5 : radioButton = RadioButton5
                        Case 6 : radioButton = RadioButton6
                        Case 7 : radioButton = RadioButton10
                        Case 8 : radioButton = RadioButton11
                    End Select

                    ' Si encontramos el RadioButton correspondiente
                    If radioButton IsNot Nothing Then
                        If estado = "Libre" Then
                            radioButton.Enabled = True
                            radioButton.ForeColor = Color.Black
                            radioButton.BackColor = SystemColors.Control
                        Else
                            radioButton.Enabled = False
                            radioButton.ForeColor = Color.White
                            radioButton.BackColor = Color.Red ' Surtidor ocupado -> Fondo rojo
                        End If
                    End If
                End While

                reader.Close()
            Catch ex As Exception
                MessageBox.Show("Error al consultar los surtidores: " & ex.Message)
            End Try
        End Using
    End Sub



    Public Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click
    End Sub

    Private Sub Btc_Click(sender As Object, e As EventArgs) Handles Btc.Click
        numeroActual = ""
        Label1.Text = "___"
    End Sub

    Private Sub BT_Click(sender As Object, e As EventArgs) Handles BT.Click
        If Not numeroActual.Contains(".") Then
            numeroActual &= "."
            Label1.Text = numeroActual
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        ' Verificar si un surtidor ha sido seleccionado
        If (RadioButton1.Checked Or RadioButton2.Checked Or RadioButton3.Checked Or RadioButton4.Checked Or
        RadioButton5.Checked Or RadioButton6.Checked Or RadioButton10.Checked Or RadioButton11.Checked) Then

            ' Verificar si se ha seleccionado una forma de pago
            If (RadioButton7.Checked Or RadioButton8.Checked Or RadioButton9.Checked) Then
                ' Obtener los datos del combustible y surtidor
                mirar_combustible()
                mirar_sortidor()

                ' Crear una nueva instancia de Form3
                Dim nuevaTransaccion As New Form3()

                ' Aplicar descuento si el cliente es verdadero
                If (Client = True) Then
                    preu_L = preu_L * 0.9 ' 10% de descuento
                End If

                ' Pasar los datos a la nueva instancia
                nuevaTransaccion.preu = preu
                nuevaTransaccion.preu_L = preu_L
                nuevaTransaccion.sortidor = sortidor

                ' Buscar la posición más a la derecha de las ventanas Form3 existentes
                Dim maxX As Integer = 1 ' Posición inicial predeterminada
                For Each form As Form3 In Application.OpenForms.OfType(Of Form3)()
                    If form.Location.X >= maxX Then
                        maxX = form.Location.X + form.Width
                    End If
                Next

                ' Ajustar la posición de la nueva ventana
                nuevaTransaccion.StartPosition = FormStartPosition.Manual
                nuevaTransaccion.Location = New Point(maxX, 0) ' Posiciona la nueva ventana a la derecha de la última

                ' Mostrar la nueva instancia de Form3
                nuevaTransaccion.Show()

                ' Desmarcar los radio buttons
                RadioButton1.Checked = False
                RadioButton2.Checked = False
                RadioButton3.Checked = False
                RadioButton4.Checked = False
                RadioButton6.Checked = False
                RadioButton7.Checked = False
                RadioButton8.Checked = False
                RadioButton9.Checked = False
                RadioButton10.Checked = False
                RadioButton11.Checked = False
            Else
                MessageBox.Show("S'ha de elegir una forma de pago.")
            End If
        Else
            MessageBox.Show("S'ha d'elegir un surtidor")
        End If
        Client = False

    End Sub


    Private Sub mirar_sortidor()
        If (RadioButton1.Checked) Then
            sortidor = 1
        End If
        If (RadioButton2.Checked) Then
            sortidor = 2
        End If
        If (RadioButton3.Checked) Then
            sortidor = 3
        End If
        If (RadioButton4.Checked) Then
            sortidor = 4
        End If
        If (RadioButton5.Checked) Then
            sortidor = 5
        End If
        If (RadioButton6.Checked) Then
            sortidor = 6
        End If
        If (RadioButton10.Checked) Then
            sortidor = 7
        End If
        If (RadioButton11.Checked) Then
            sortidor = 8
        End If
    End Sub

    Private Sub mirar_combustible()
        Dim precio As Double
        ' Abrimos la conexión con la base de datos
        Using conn As New SqlConnection(connectionString)
            Try
                conn.Open() ' Primero abrimos la conexión

                ' Iniciamos la transacción
                Dim transaction As SqlTransaction = conn.BeginTransaction()

                ' Preparamos la consulta con parámetros
                Dim query As String = "SELECT nombre, precio FROM Combustibles WHERE nombre = @nom"
                Dim cmdGetFormula As New SqlCommand(query, conn, transaction)
                cmdGetFormula.Parameters.AddWithValue("@nom", Form1.carburant)

                ' Ejecutamos la consulta
                Dim reader As SqlDataReader = cmdGetFormula.ExecuteReader()

                ' Iteramos sobre los resultados obtenidos
                While reader.Read()
                    Dim nom As String = reader("nombre").ToString() ' Cambiado a String
                    precio = 0
                    precio = reader("precio").ToString()

                    ' Mostramos los valores obtenidos
                End While
                reader.Close()

                ' Confirmamos la transacción
                transaction.Commit()

            Catch ex As Exception
                MessageBox.Show("Error al consultar los surtidores: " & ex.Message)
            End Try
        End Using
        Dim nombre As Double
        If Double.TryParse(Label1.Text, nombre) Then
            preu_L = precio
            preu = nombre
        Else
            MessageBox.Show("El valor de Label1 no es un número válido.")
        End If
    End Sub

    ' Para actualizar los surtidores cuando el Form2 se activa
    Private Sub Form2_Activated(sender As Object, e As EventArgs) Handles MyBase.Activated
        ActualizarSurtidores() ' Cada vez que el Form2 se active, se actualiza
    End Sub

    Private Sub RadioButton9_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton9.CheckedChanged
        If RadioButton9.Checked Then
            Form4.Show()
        End If
    End Sub


    Private Sub RadioButton8_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton8.CheckedChanged

    End Sub

    Private Sub GroupBox4_Enter(sender As Object, e As EventArgs) Handles GroupBox4.Enter

    End Sub
End Class
