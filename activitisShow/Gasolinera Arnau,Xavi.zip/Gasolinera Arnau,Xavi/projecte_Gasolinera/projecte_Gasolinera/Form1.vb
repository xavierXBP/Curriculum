﻿Imports System.Data.SqlClient

Public Class Form1
    Dim connectionString As String = "Server=XAVI\SQLEXPRESS;Database=Gasolinera;Integrated Security=True;"

    Private Sub Label1_Click(sender As Object, e As EventArgs)

    End Sub
    Public carburant As String = ""


    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Me.Size = New Size(5500, 4400)
        Me.Location = New Point(0, 0)

        Text = "Combustibles"
        Button1.Font = New Font("Arial", 15, FontStyle.Bold)
        Button2.Font = New Font("Arial", 15, FontStyle.Bold)
        Button3.Font = New Font("Arial", 15, FontStyle.Bold)
        Button4.Font = New Font("Arial", 15, FontStyle.Bold)
        Button5.Font = New Font("Arial", 15, FontStyle.Bold)
        Button6.Font = New Font("Arial", 15, FontStyle.Bold)
        Button7.Font = New Font("Arial", 15, FontStyle.Bold)
        Button8.Font = New Font("Arial", 15, FontStyle.Bold)


    End Sub

    Private Sub TabPage1_Click(sender As Object, e As EventArgs) Handles TabPage1.Click

    End Sub





    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        DesmarcarTodosCheckBox(Me)
        CheckBox1.Checked = True
        carburant = "Gasolina 95"
    End Sub
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        DesmarcarTodosCheckBox(Me)
        CheckBox2.Checked = True
        carburant = "Gasolina 98"
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        DesmarcarTodosCheckBox(Me)
        CheckBox3.Checked = True
        carburant = "Diesel"
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        DesmarcarTodosCheckBox(Me)
        CheckBox4.Checked = True
        carburant = "Biodièsel"
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        DesmarcarTodosCheckBox(Me)
        CheckBox5.Checked = True
        carburant = "Biotanol"
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        DesmarcarTodosCheckBox(Me)
        CheckBox6.Checked = True
        carburant = "Gasoil"
    End Sub
    Private Sub Button8_Click_2(sender As Object, e As EventArgs) Handles Button8.Click
        DesmarcarTodosCheckBox(Me)
        CheckBox7.Checked = True
        carburant = "Electricitat"
    End Sub

    Public Sub DesmarcarTodosCheckBox(controlParent As Control)
        For Each control As Control In controlParent.Controls
            ' Verifica si el control es un CheckBox
            If TypeOf control Is CheckBox Then
                ' Desmarcamos el CheckBox
                CType(control, CheckBox).Checked = False
                Console.WriteLine("Desmarcado: " & control.Name) ' Agrega depuración
                carburant = ""
            End If

            ' Llamada recursiva si el control tiene otros controles dentro
            If control.HasChildren Then
                DesmarcarTodosCheckBox(control)
            End If
        Next
    End Sub


    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        'Comprueba si hay algun check box activo antes de destinarlo al sortidor.'
        If (CheckBox1.Checked Or CheckBox2.Checked Or CheckBox3.Checked Or CheckBox4.Checked Or CheckBox5.Checked Or CheckBox6.Checked Or CheckBox7.Checked = True) Then
            Form2.carburanteSeleccionado = carburant
            Form2.numeroActual = ""
            Form2.Show()

        Else
            ' Si no hay ninguno marcado, mostramos el mensaje
            MessageBox.Show("Se debe marcar al menos un carburante.")
        End If


    End Sub

    Private Sub Button8_Click(sender As Object, e As EventArgs)
        Form5.Show()
    End Sub

    Private Sub TabPage2_Click(sender As Object, e As EventArgs) Handles TabPage2.Click

    End Sub
    Private Sub CargarTransacciones()
        ' Crear una conexión a la base de datos
        Using conn As New SqlConnection(connectionString)
            ' Definir la consulta SQL para obtener los datos de la tabla Transacciones
            Dim query As String = "SELECT t.precio, t.litros, t.fecha, nivel_actual," &
                                  "c.nombre AS combustible " &
                                  "FROM Transacciones t " &
                                  "JOIN Combustibles c ON t.id_combustible = c.id_combustible"

            ' Crear un comando SQL con la consulta y la conexión
            Using cmd As New SqlCommand(query, conn)
                ' Crear un adaptador de datos para llenar un DataTable
                Using da As New SqlDataAdapter(cmd)
                    ' Crear un DataTable para almacenar los resultados
                    Dim dt As New DataTable()

                    ' Abrir la conexión y llenar el DataTable
                    Try
                        conn.Open()
                        da.Fill(dt)

                        ' Asignar el DataTable al DataGridView
                        DataGridView1.DataSource = dt
                    Catch ex As Exception
                        ' Manejar cualquier error de conexión o consulta
                        MessageBox.Show("Error al cargar las transacciones: " & ex.Message)
                    End Try
                End Using
            End Using
        End Using
    End Sub

    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click
        CargarTransacciones()
    End Sub

    Private Sub Button8_Click_1(sender As Object, e As EventArgs)
        Form5.Show()

    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick

    End Sub



    Sub VerificarNivelDeposito()
        Dim niv_total As Decimal
        ' Cadena de conexión a la base de datos
        Dim connectionString As String = "Server=XAVI\SQLEXPRESS;Database=Gasolinera;Integrated Security=True;"

        ' Consulta SQL para obtener los valores de nivel_actual y capacidad_total de todos los depósitos
        Dim query As String = "SELECT id_deposito, nivel_actual, capacidad_total FROM Depositos"

        ' Conexión a la base de datos
        Using conn As New SqlConnection(connectionString)
            Try
                conn.Open()

                ' Crear y ejecutar el comando SQL
                Using cmd As New SqlCommand(query, conn)
                    Using reader As SqlDataReader = cmd.ExecuteReader()
                        ' Leer los registros
                        While reader.Read()
                            ' Obtener los valores de nivel_actual, capacidad_total e id_deposito
                            Dim idDeposito As Integer = Convert.ToInt32(reader("id_deposito"))
                            Dim nivelActual As Decimal = Convert.ToDecimal(reader("nivel_actual"))
                            Dim capacidadTotal As Decimal = Convert.ToDecimal(reader("capacidad_total"))

                            ' Verificar si el nivel_actual es menor al 10% de la capacidad_total
                            If nivelActual < (capacidadTotal * 0.1D) Then
                                niv_total = capacidadTotal - nivelActual

                                ' Mostrar el mensaje de alerta
                                MessageBox.Show($"Alerta: El nivel actual del depósito {idDeposito} ({nivelActual}) es inferior al 10% de la capacidad total ({capacidadTotal}).",
                                            "Advertencia", MessageBoxButtons.OK, MessageBoxIcon.Warning)

                                ' Actualizar nivel_actual e is_deposito y registrar recarga
                                ActualizarDeposito(idDeposito, capacidadTotal, niv_total, connectionString)
                            End If

                            ' Si el nivel_actual ya es igual a la capacidad_total, actualizar is_deposito
                            If nivelActual = capacidadTotal Then
                                ActualizarDeposito(idDeposito, capacidadTotal, 0, connectionString)
                            End If
                        End While
                    End Using
                End Using
            Catch ex As Exception
                ' En caso de error, mostrar el mensaje de excepción
                MessageBox.Show($"Ocurrió un error al verificar los depósitos: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End Using
    End Sub

    ' Función para actualizar nivel_actual, is_deposito y registrar la recarga
    Sub ActualizarDeposito(idDeposito As Integer, nuevaCapacidad As Decimal, totalLitros As Decimal, connectionString As String)
        Dim updateQuery As String = "UPDATE Depositos SET nivel_actual = @nuevaCapacidad WHERE id_deposito = @idDeposito"

        Using conn As New SqlConnection(connectionString)
            Try
                conn.Open()
                Using cmd As New SqlCommand(updateQuery, conn)
                    cmd.Parameters.AddWithValue("@nuevaCapacidad", nuevaCapacidad)
                    cmd.Parameters.AddWithValue("@idDeposito", idDeposito)
                    cmd.ExecuteNonQuery()
                End Using

                ' Si hubo una recarga, insertar en recargaDeposito
                If totalLitros > 0 Then
                    InsertarRecarga(idDeposito, totalLitros, connectionString)
                End If
            Catch ex As Exception
                MessageBox.Show($"Error al actualizar el depósito {idDeposito}: {ex.Message}",
                            "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End Using
    End Sub

    ' Función para insertar una nueva recarga en la tabla recargaDeposito
    Sub InsertarRecarga(idDeposito As Integer, totalLitros As Decimal, connectionString As String)
        Dim insertQuery As String = "INSERT INTO recargaDeposito (fecha, id_deposito, total_litros) VALUES (@fecha, @idDeposito, @totalLitros)"

        Using conn As New SqlConnection(connectionString)
            Try
                conn.Open()
                Using cmd As New SqlCommand(insertQuery, conn)
                    cmd.Parameters.AddWithValue("@fecha", DateTime.Now.Date)
                    cmd.Parameters.AddWithValue("@idDeposito", idDeposito)
                    cmd.Parameters.AddWithValue("@totalLitros", totalLitros)
                    cmd.ExecuteNonQuery()
                End Using
            Catch ex As Exception
                MessageBox.Show($"Error al insertar recarga para el depósito {idDeposito}: {ex.Message}",
                            "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End Using
    End Sub
    Private Sub CargarDatos()
        Try
            Using conexion As New SqlConnection(connectionString)
                Dim consulta As String = "SELECT id, fecha, id_deposito, total_litros FROM recargaDeposito"
                Dim adaptador As New SqlDataAdapter(consulta, conexion)
                Dim tabla As New DataTable()
                adaptador.Fill(tabla)
                DataGridView1.DataSource = tabla
            End Using
        Catch ex As Exception
            MessageBox.Show("Error al cargar los datos: " & ex.Message)
        End Try
    End Sub




    Private Sub Button10_Click(sender As Object, e As EventArgs) Handles Button10.Click
        VerificarNivelDeposito()
        CargarDatos()

    End Sub

    Private Sub GroupBox1_Enter(sender As Object, e As EventArgs) Handles GroupBox1.Enter

    End Sub
End Class
