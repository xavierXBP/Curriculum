﻿
Imports System.Data.SqlClient

Public Class Form5
    Private Sub Form5_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Me.Size = New Size(500, 400)
        Me.Location = New Point(0, 0)



    End Sub
End Class
